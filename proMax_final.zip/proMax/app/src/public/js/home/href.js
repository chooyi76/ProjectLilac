function newPage() {
  window.location.href = "register";
}
function loginpage() {
  window.location.href = "login";
}
function alertlogin(){
  window.alert("로그인이 필요합니다");
}
