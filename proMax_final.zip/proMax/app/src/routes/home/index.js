"use strict";
const Web3 = require('web3');
const Contract = require('web3-eth-contract');
const bcrypt = require ('bcrypt');
//const crypto = require ('crypto');
const express = require("express");
const router = express.Router();

const ctrl = require("./home.ctrl");

router.get("/", ctrl.output.home);
router.get("/login", ctrl.output.login);
router.get("/register", ctrl.output.register);
router.get("/willwrite", ctrl.output.will);
router.get("/loginpass",ctrl.output.loginpass);
router.get("/willupdate", ctrl.output.willup);

router.post("/login", ctrl.process.login);
router.post("/register", ctrl.process.register);
router.post("/willwrite", ctrl.process.will);
router.post("/willupdate", ctrl.process.willupdate);

module.exports = router;
